# Core_Java_Mysql_Project
Student Management System
